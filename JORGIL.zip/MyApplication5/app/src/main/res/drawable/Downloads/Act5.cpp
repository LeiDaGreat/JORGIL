/* Jorgil, John Lei N.
	Act 5
*/

#include <iostream>
using namespace std;
int main()

{
	
	float num1, num2, sum, difference, product, qoutient, radius;
	int a1, a2;
	
	cout<<"Enter First Number: ";
	cin>>num1;
	cout<<"Enter Second Number: ";
	cin>>num2;
	
	
	
	sum = num1+num2;
	difference = num1-num2;
	product = num1*num2;
	qoutient = num1/num2;
	radius = a1&a2;
	
	a1 = num1;
	a2= num2;
	
	cout<<"The Sum of the two numbers is: "<<sum<<endl;
	cout<<"The Difference of the two numbers is: "<<difference<<endl;
	cout<<"The Product of the two numbers is: "<<product<<endl;
	cout<<"The Qoutient of the two numbers is: "<<qoutient<<endl;
	cout<<"The Radius of the two numbers is: "<<radius<<endl;
	
	return 0;
}
