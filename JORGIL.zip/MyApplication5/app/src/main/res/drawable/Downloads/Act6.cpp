/* Jorgil, John Lei N.
	Act 6
*/

#include <iostream>
using namespace std;
int main()
{
	int *ptr1, *ptr2;
	int num1 = 18, num2=35, result;
	
	ptr1 = &num2;
	ptr2 = &num1;
	
	num2 = 6;
	
	result = *ptr1 + *ptr2 + (num1 *num2);
	
	cout<<*ptr1<<*ptr2<<endl;
	cout<<num1<<"\t"<<num2<<"\t"<<result<<endl;
	cout<< (num2 == *ptr1)<<endl;
	
	return 0;
	
	
}
