/* Jorgil, John Lei N.
	Act 4
*/

#include <iostream>
using namespace std;
int main()
{
	int num1,num2,result;
	int *ptr1, *ptr2;
	
	cout<<"Enter First Number: ";
	cin>>num1;
	cout<<"Enter Second Number: ";
	cin>>num2;
	
	ptr1 = &num1;
	ptr2 = ptr1;
	
	result = num1 + num2 + *ptr1;
	cout<<"The Value num1 is "<<num1<<endl
	<<"The Value num2 is "<<num2<<endl
	<<"The Value ptr1 is "<<ptr1<<endl
	<<"The Value ptr2 is "<<ptr2<<endl
	<<"The Result is "<<result<<endl;
	
	return 0;
}
